export interface Formspree {
  firstName: String,
  lastName: String,
  address: String,
  phoneNumber: Number,
  email: String,
  zipCode: Number,
}
