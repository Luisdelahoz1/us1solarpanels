import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mailchimp',
  templateUrl: './mailchimp.component.html',
  styleUrls: ['./mailchimp.component.scss']
})
export class MailchimpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
